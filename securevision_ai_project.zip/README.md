# SecureVision AI
Image Retrieval & Visual Q&A for Security Operations.

## Features
- Upload security screenshots and images
- Ask visual questions about an image
- Store image metadata and embeddings
- Retrieve relevant images using text queries
- Security-oriented analysis prompts
- Streamlit frontend and FastAPI backend

## Quick Start
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn backend.main:app --reload
streamlit run frontend/app.py
```

Set `OPENAI_API_KEY` in `.env` if using a compatible vision model.
This starter project uses safe, defensive analysis only.
