import os
from PIL import Image

SYSTEM_PROMPT = (
    "You are a defensive cybersecurity visual analyst. "
    "Analyze images for SOC investigations. Do not provide instructions "
    "for exploitation, credential theft, evasion, or unauthorized access. "
    "Mention uncertainty and avoid claiming that visual evidence proves an incident."
)

def analyze_image(image: Image.Image, question: str) -> dict:
    # Replace this function with your selected vision-model SDK integration.
    # The fallback keeps the application runnable without an API key.
    if not os.getenv("OPENAI_API_KEY"):
        return {
            "mode": "demo",
            "answer": (
                "Demo response: configure OPENAI_API_KEY and connect a vision model "
                "to receive image-specific analysis."
            ),
            "security_notes": [
                "Treat screenshots as untrusted evidence.",
                "Redact credentials and personal data before sharing.",
                "Validate findings using logs and other telemetry."
            ]
        }

    return {
        "mode": "integration_pending",
        "answer": (
            "Vision provider detected. Implement the provider SDK call in "
            "backend/services/vision_service.py."
        ),
        "system_prompt": SYSTEM_PROMPT,
        "question": question
    }
